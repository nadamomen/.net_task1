// Online C# compiler (editor) for free
// Write and run C# online using this editor.

using System;

public class HelloWorld {
    public static void Main(string[] args) {
       //q1
        Object obj= new Book();
        Console.WriteLine(obj);
        //q2
        Console.WriteLine(obj.ToString());
        Console.WriteLine(obj.Equals(obj));
        Console.WriteLine(obj.GetHashCode());
        Console.WriteLine(obj.GetType());
        /*q3
        * int pages = "464"; compile-time error 
        * int pages = 464;
        */
        
      //q4
        try{
            int x = 0 ; 
            int g = 10/x ;
        }catch(Exception ex){
            Console.WriteLine("Cannot divide by zero");
        }finally{
            Console.WriteLine("Done");
        }

        //q5
        int pages = 300 ; 
        double d = pages ;
        //q6
       double price = 49.99 ;
        int i = (int)price ;
        //q7
        string pagesText = "464" ;
        int pages_int =Convert.ToInt32(pagesText);
        //q8
        string yearText = "2023";
        int year = int.Parse(yearText);
        string badText = "abc" ; 
        bool yes = int.TryParse(badText,out int badnum);
       if(!yes)Console.WriteLine("Invalid number");
        //q9 pages declared in q5
        string sbages = pages.ToString();
        Console.WriteLine(sbages.GetType());
        //q10
         int copies = 100;
        Object objvar = copies ;
        int intvar = (int)objvar ;
        Console.WriteLine(objvar);
        Console.WriteLine(intvar);
        //q11
        int? year1 = null ; 
       Console.WriteLine(year1.HasValue?"year has a value":"year doesn't has a value");
            year1 = 2023 ; 
        Console.WriteLine(year1);
        //q12
        string? reviewer = null ;
         Console.WriteLine(reviewer==null?"it's null":"it's not null");
        //q13
         Book? book = null;
        Console.WriteLine(book?.title);
        //q14
        Console.WriteLine(book?.title ?? "untitled");
        book = new Book();
        if(book?.title == null)
        book.title ??= "untitled";
        //q15
         string? name = "Ahmed" ; 
        string confirmedName = name!;
        
    }
}
public class Book{
   public string title ;
   
   public int pages = 464 ;
    
    
}
